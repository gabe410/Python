#File:    proj3.py
#Author:  Gabe Maturo
#Date:    4/30/19
#Section: 5
#Email:   ak36939@umbc.edu
#Description: This program plays the game "Minesweeper"

#info for game pieces and board
OCTOTHORPE = "#"
PERIOD = "."
SPACE = " "
FLAG = "F"
DETONATE = "X"
MINE = "*"

###################################################
# mineSweepGame()  essentially runs the game
# Parameters:      board;   the rectangular 2d gameboard
#                  answerboard; the 2d gameboard with the spaces revealed
# Return:          None;
def mineSweeperGame(board, answerBoard):

    #get the mines left to print at the start
    minesLeft(board, answerBoard)

    #use boolean and while loop to run the game until a mine
    #is detonated or the game is won
    gameOver = False

    while gameOver == False:

        #print the board each turn
        prettyPrintBoard(board)
        #get the move and execute the move
        getMove(board, answerBoard)
        #print how many mines are left
        gameWon = minesLeft(board, answerBoard)

        #if the mine is detonated, game is over
        if gameWon == 2:

            gameOver = True
            prettyPrintBoard(board)
            print("You detonated a mine! Game over!")

        #if all of the mines are correctly flagged, game over    
        if gameWon == 1:

            gameOver = True
            prettyPrintBoard(board)
            print("You won! Congratulations, and good game!")

###################################################
# minesLeft()  checks how many mines are left
# Parameters:  board; the 2d gameboard
#              answerBoard; the 2d gameboard with the spaces revealed
# Return:      1 or 2; whether the game is won or lost
def minesLeft(board, answerBoard):

    mineCounter = 0
    flagCounter = 0
    mineTracker = 0

    #use for loop to check how many mines are on the board
    for row in range(len(answerBoard)):

        for column in range(len(answerBoard[row])):

            if answerBoard[row][column] == MINE:

                mineCounter += 1
                mineTracker += 1

    #check the board for all of the mines that are correctly flagged
    for i in range(len(board)):

        for j in range(len(board[i])):

            if board[i][j] == FLAG and answerBoard[i][j] == MINE:

                flagCounter += 1

            if board[i][j] == FLAG and answerBoard[i][j] != MINE:

                mineCounter -= 1

    #to get mines left subtract the number of mines from the number of flags
    minesLeft = mineCounter - flagCounter                
    print(" \n \n There are", minesLeft, "mines left to find")

    #check to see if a mine has been detonated, game is lost
    for row in range(len(board)):

        for column in range(len(board[row])):

            if board[row][column] == DETONATE:

                return 2

    #check to see if all of the mines are correctly flagged, game is won
    if flagCounter == mineTracker and minesLeft == 0:

        return 1

    else:
        return 0

###################################################
# getMove()    gets the move that the user wishes to execute
#              and the gameboard that they wish to use
# Parameters:  board; the 2d gameboard
#              answerBoard; the 2d gameboard with the spaces revealed
# Return:      None;
def getMove(board, answerBoard):

    #use boolean to check the user input validity for the row
    rowValid = False

    while not rowValid:
        row = int(input("Please choose the row: \n Enter a number between 1 and "+str(len(board) - 2)+" (inclusive): "))
        rowValid = True

        #if the row value is too big, it is not valid
        if row > len(board) - 2:
            print("That number is not allowed. Please try again!")
            rowValid = False

        #if the row value is too small, it is not valid
        if row < 1:
            print("That number is not allowed. Please try again!")
            rowValid = False

    #use boolean to check the user input validity for the column
    columnValid = False

    while not columnValid:
        column = int(input("Please choose the column: \n Enter a number between 1 and "+str(len(board) - 2)+" (inclusive): "))
        columnValid = True

        #if the column value is too big, it is not valid
        if column > len(board) - 2:
            print("That number is not allowed. Please try again!")
            columnValid = False

        #if the column value is too small, it is not valid
        if column < 1:
            print("That number is not allowed. Please try again!")
            columnValid = False

    #checks the user input validity for the move they want to execute
    moveValid = False

    while not moveValid:        
        move = input("Enter 'r' to reveal the space or, enter 'f' to mark the space with a flag: ")
        moveValid = True

        #if the move is not 'r' or 'f', it is not valid
        if move != "r" and move != "f":
            print("That's not a valid action.")
            moveValid = False

    #execute the user input
    mineSweep(board, answerBoard, row, column, move)

###################################################
# mineSweep()  makes the move and updates the  game board
#              after each reveal is made
# Parameters:  board;  the rectangular 2d gameboard
#              answerboard; the 2d gameboard with the spaces revealed
#              row; the row the user wants to access in the board
#              column; the column the user wants to access in the board
#              action; the action the user wants to execute
# Return:      None;
def mineSweep(board, answerBoard, row, column, action):

    #if they want to reveal and it is a flag, make them unflag it first
    if action == "r" and board[row][column] == FLAG:

        print(" \n \n Field", row, ",", column, "must be unflagged before it can be revealed")

    #if they want to flag a spot, take the input and put it into the
    #flag() function
    if action == "f":

        flag(board, answerBoard, row, column)

    #if they want to reveal a spot, take the input and put it into the
    #reveal() function
    if action == "r" and board[row][column] != FLAG:

        reveal(board, answerBoard, row, column)

###################################################
# flag()       if the user chooses to flag, this function will
#              either place or remove a flag, or not place a flag if
#              it has already been revealed
# Parameters:  board;  the rectangular 2d gameboard
#              answerboard; the 2d gameboard with the spaces revealed
#              row; the row the user wants to access in the board
#              column; the column the user wants to access in the board
# Return:      None;
def flag(board, answerBoard, row, column):

    #if the piece is a flag, remove the flag
    if board[row][column] == FLAG:

        board[row][column] = PERIOD
        print(" \n \n Flag removed from", row, ",", column)

    #otherwise put a flag on the space the user wants
    else:
        board[row][column] = FLAG

###################################################
# reveal()     reveals what is underneath the period on the
#              gameboard
# Parameters:  board; the rectangular 2d gameboard
#              answerboard; the 2d gameboard with the spaces revealed
#              row; the row the user wants to access in the board
#              column; the column the user wants to access in the board
# Return:      None;
def reveal(board, answerBoard, row, column):

    #if the spot is a blank space, run the island() function to open
    #the other blank spaces and reveal the island
    if answerBoard[row][column] == SPACE:

        island(board, answerBoard, row, column)

    #if it is a mine, change the piece to an 'X'
    if answerBoard[row][column] == MINE:

        board[row][column] = DETONATE
        
    #otherwise just reveal the space
    else:
        
        board[row][column] = answerBoard[row][column]

###################################################
# island()     recursively fills out the "island" of empty space when
#              an empty field is revealed
# Parameters:  board; the rectangular 2d gameboard
#              answerboard; the 2d gameboard with the spaces revealed
#              row; the row the user wants to access in the board
#              column; the column the user wants to access in the board
# Return:      None;
def island(board, answerBoard, row, column):

    #Base case saying that if it is not a space, then reveal the space
    if answerBoard[row][column] != SPACE:

        board[row][column] = answerBoard[row][column]

    #Second base case saying that if it is not a dot, then reveal the space
    if board[row][column] != PERIOD:

        board[row][column] = answerBoard[row][column]

    #recursive case that says to keep revealing all of the empty spaces and
    #the numbers that border the island
    else:
        board[row][column] = answerBoard[row][column]
        island(board, answerBoard, row + 1, column)
        island(board, answerBoard, row - 1, column)
        island(board, answerBoard, row, column + 1)
        island(board, answerBoard, row, column - 1)
        island(board, answerBoard, row + 1, column + 1)
        island(board, answerBoard, row - 1, column + 1)
        island(board, answerBoard, row - 1, column - 1)
        island(board, answerBoard, row + 1, column - 1)
        board[row + 1][column + 1] = answerBoard[row + 1][column + 1]
        board[row - 1][column + 1] = answerBoard[row - 1][column + 1]
        board[row + 1][column - 1] = answerBoard[row + 1][column - 1]
        board[row - 1][column - 1] = answerBoard[row - 1][column - 1]

###################################################
# clue()       determines the "clue" for each field by counting
#              the number of mines it touches for each board being read in
# Parameters:  board; the rectangular 2d gameboard
# Return:      None;
def clue(board):

    #for loop that goes through each space on the board
    #and checks if there is a mine, if there is a mine,
    #then add to the counter. After all 8 spaces around
    #the current space have been checked for mines,
    #then set the current space equal to the counter
    for row in range(1, len(board) - 1):

        for column in range(1, len(board[row]) - 1):

           if board[row][column] == SPACE:
               mineCount = 0

               if board[row - 1][column] == MINE:
                   mineCount += 1

               if board[row + 1][column] == MINE:
                   mineCount += 1

               if board[row][column + 1] == MINE:
                   mineCount += 1

               if board[row][column - 1] == MINE:
                   mineCount += 1

               if board[row + 1][column + 1] == MINE:
                   mineCount += 1

               if board[row + 1][column - 1] == MINE:
                   mineCount += 1

               if board[row - 1][column - 1] == MINE:
                   mineCount += 1

               if board[row - 1][column + 1] == MINE:
                   mineCount += 1

               board[row][column] = str(mineCount) 

    #sets any zeros equal to an empty space
    for row in range(len(board)):

        for column in range(len(board[row])):
            
            if board[row][column] == "0":
                board[row][column] = SPACE

###################################################
# prettyPrintBoard() prints the board with row and column labels,
#                    and spaces the board out so that it looks square
# Parameters:        board;   the rectangular 2d gameboard to print
# Return:            none; prints the board in a pretty way
def prettyPrintBoard(board):

    print() #empty line

    #if enough columns, print a "tens column" line above
    if len(board[0])-2 >= 10:
        print("{:25s}".format(""), end="")  #empty space for 1 - 9
        for i in range(10, len(board[0])-1 ):
            print( str(i // 10), end =" ")
        print()

    #create and print top numbered line
    print("       ", end="")
    #only go from 1 to len - 1, so we don't number the borders
    for i in range(1, len(board[0])-1 ):
        #only print the last digit (so 15 --> 5)
        print(str(i % 10), end = " ")

    print()

    #create the border row
    borderRow = "     "
    for col in range(len(board[0])):
        borderRow += board[0][col] + " "

    #print the top border row
    print(borderRow)

    #print all the interior rows
    for row in range(1, len(board) - 1):
        #print the row label
        print("{:3d}  ".format(row), end="")

        #print the row contents
        for col in range(len(board[row])):
            print(str(board[row][col]), end = " ")
        print()

    #print the bottom border row and an empty line
    print(borderRow, "\n")
        
def main():

    #prints the opening statement
    print()
    print("This program allows you to play Minesweeper. \n The object of the game is to flag every mine, \n using clues about the number of neighboring \n mines in each field. To win the game, flag \n all of the mines (and don't incorrectly flag \n any non-mine fields). Good luck!")
    print()

    #gets and reads in the board that the user wants to play with
    board = input("Enter the file to load the board from: ")
    boardChoice = open(board, "r")
    answerFile = boardChoice.readlines()

    #creates a 2D list that the user will use (mineSweeper), and a 2D list
    #to compare the answers to (answerList)
    answerList = []
    mineSweeper = []

    #puts the values from the .txt file into the 2D lists
    for i in range(len(answerFile)):
        answerFile[i] = answerFile[i].strip()
        aList = []
        mineList = []
        
        for j in range(len(answerFile[i])):

            aList.append(answerFile[i][j])
            mineList.append(answerFile[i][j])
            
        answerList.append(aList)
        mineSweeper.append(mineList)

    #makes the user board by replacing all of the values with periods
    for i in range(len(mineSweeper)):
      
        for j in range(len(mineSweeper[i])):

            if mineSweeper[i][j] == " " or mineSweeper[i][j] == MINE:
                mineSweeper[i][j] = PERIOD

    #create the answerBoard by putting it into the clue() function
    clue(answerList)

    #run the game with the user board and the answer board to compare it to
    mineSweeperGame(mineSweeper, answerList)
    
main()
