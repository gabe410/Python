# File:    proj1.py
# Author:  Gabe Maturo
# Date:    3/30/19
# Section: 5
# E-mail:  ak36939@umbc.edu
# Description:
#    Takes a hawaiian phrase that the user inputs and gives the user
#    the correct pronunciation of the phrase

#info about characters
OKINA       = "'"
NON_VOWELS  = ["h", "k", "l", "m", "n", "p", "w", " "]
VOWELS      = ["a", "e", "i", "o", "u"]
COMP_VOWELS = ["ai", "ae", "ao", "au", "ei", "eu", "iu", "oi", "ou", "ui"]
W_LETTER    = "w"

#info for getting choice
OPTIONS = ["y", "yes", "n", "no"]
CONTINUE = "Do you want to enter another word? "

#info for pronunciation printing
DASH = "-"

###################################################
# getHawaiianPhrase() prompts and reprompts the user until
#                     they enter in a valid Hawaiian phrase
#                     and then prints the correct pronunciation
#                     of the phrase
# Parameters: None; takes in no input
# Return: None; prints phrase in function
def getHawaiianPhrase():

    #using Boolean operators to make sure the user enters a valid phrase
    validPhrase = False
    index = 0
    index2 = 0

    while not validPhrase:

        #gets initial user input
        hPhrase = input("Enter a Hawaiian phrase to pronounce: ")
        validPhrase = True
        #makes it case insensitive
        hPhraseLower = hPhrase.lower()
        hPhrasePrint = hPhrase.split()
        #splits it and makes it case insensitive so it can check each leter
        hPhraseCheck = hPhraseLower.split()

        while index < len(hPhraseCheck):
            
            #checks if the word ends in a vowel
            if hPhraseCheck[index][len(hPhraseCheck[index]) - 1] not in VOWELS:
                print("The word", hPhrasePrint[index], "does not end in a vowel")
                validPhrase = False

            index += 1

        index = 0
        
        while index < len(hPhraseCheck):

            while index2 < len(hPhraseCheck[index]):

                #checks to see if the letter is in the Hawaiian alphabet
                if hPhraseCheck[index][index2] not in VOWELS and hPhraseCheck[index][index2] not in NON_VOWELS and hPhraseCheck[index][index2] not in OKINA:
                    
                    print("The letter", hPhrasePrint[index][index2], "is not valid")
                    validPhrase = False
                index2 += 1
                
            index2 = 0
            index += 1
            
        index = 0
        
    hawPhrase = hPhrase
    
    #prints the valid phrase the user entered
    print("The phrase", hPhrase.upper(), "is pronounced: ")
    #prints the pronunciation of the phrase(runs it through pronounce function)
    print(pronounce(hawPhrase))

###################################################
# getChoice() prompts and reprompts the user until
#             they select a valid choice
# Parameters: None; asks if user wants to enter another phrase
# Return:     None; if user hits no, the program ends, if they hit yes
#                   then it will run the program again and ask for a
#                   phrase
def getChoice():

    #used boolean operator to make sure user enters yes, y, n, or no
    validChoice = False

    while not validChoice:

        #asks user if they want to enter another phrase
        question = input(CONTINUE + "(y/yes/n/no): ")
        validChoice = True
        #makes it case insensitive
        questionCheck = question.lower()

        if questionCheck not in OPTIONS:
            print("Enter y/yes/n/no")
            validChoice = False

    #if the user enters y or yes, it runs the program again
    if question.lower() == "y" or question.lower() == "yes":

        main()

###################################################
# simpleVowel(letter) determines how a vowel is pronounced
# Parameters: single-character string
# Return: simVowel; how vowel is pronounced
def simpleVowel(letter):

    #doing this allows a non-vowel letter to go through the function
    #without making any changes to it
    simVowel = letter

    #each if statement makes a change to the vowel, giving it the correct
    #pronunciation, depending on which vowel it is
    if letter == "a":
        simVowel = "ah-"

    elif letter == "e":
        simVowel = "eh-"
        
    elif letter == "i":
        simVowel = "ee-"
    
    elif letter == "o":
        simVowel = "oh-"
    
    elif letter == "u":
        simVowel = "oo-"

    #returns the letter that is entered in either with or without changes
    #being made to it
    return simVowel

def complexVowel(vowels):

    #allows two non-vowels to go through without making changes
    comVowel = vowels

    #changes each set of complex hawaiin vowels to their pronunciation
    if vowels == "ai" or vowels == "ae":
        comVowel = "eye"

    elif vowels == "ao" or vowels == "au" or vowels == "ou":
        comVowel = "ow"

    elif vowels == "ei":
        comVowel = "ay"

    elif vowels == "eu":
        comVowel = "eh-oo"

    elif vowels == "iu":
        comVowel = "ew"

    elif vowels == "oi":
        comVowel = "oy"

    elif vowels == "ui":
        comVowel = "ooey"

    #adds a dash to the end of each complex vowel pronunciation
    comVowel += DASH
    #returns the two letters back, either with or without changes being made
    return comVowel

###################################################
# pronounceW(word, index) determines how a "w" should be pronounced
# Parameters: string; word "w" exists in
#             integer; index where "w" resides
# Return: "v" or "w"; depending on the pronunciation
def pronounceW(word, index):
    
    letterW = word[index]

    #followed checks what letter comes before the 'w'
    followed = word[index - 1:index + 1]

    #if the first letter is a 'w', then it doesn't change
    if index == 0:
        letterW = "w"

    #if the 'w' is followed by an 'a', 'e', or 'i' it changes to a 'v'
    elif followed == "aw" or followed == "ew" or followed == "iw":
        letterW = "v"

    #otherwise the 'w' stays the same
    else:
        letterW = "w"

    #returns the correct changes to the letter 'w'
    return letterW

###################################################
# pronounceWord(word) determines how to pronounce a single word
# Parameters: string; no spaces
# Return: pronWord; the word's pronunciation
def pronounceWord(word):

    index = 0
    #creates an empty string
    hWord = ""
    #makes it case insensitive
    haWord = word.lower()

    #cycles through each letter of the word
    while index < len(haWord):

        #says that if any two letters in the word are a complex vowel,
        #run them through the complexVowel function and make changes to them
        if haWord[index:index + 2] in COMP_VOWELS:
            hLetter = complexVowel(haWord[index:index + 2])
            #adds the changes made to the string hWord
            hWord = hWord + hLetter
            #index by 2 because you don't want it to do the same letter twice
            index += 2

        #if the letter is an okina, get rid of the dash that comes before it
        #and run the okina through the simpleVowel function
        elif haWord[index] == OKINA:
            hLetter = simpleVowel(haWord[index])
            #adds all of the hWord except for the dash and then adds the okina
            #to hWord
            hWord = hWord[0:len(hWord)-1] + hLetter
            index += 1

        #if the letter is a 'w', run it through the pronounceW function
        #to get the correct pronunciation
        elif haWord[index] == "w":
            hLetter = pronounceW(haWord, index)
            #then add the 'w' to hWord
            hWord = hWord + hLetter 
            index += 1

        #otherwise just run the letter through the simpleVowel function
        #and get the correct pronunciation
        else:
            hLetter = simpleVowel(haWord[index])
            #then add this letter to hWord
            hWord = hWord + hLetter 
            index += 1

    #gets rid of the dash at the end of each word
    pronWord = hWord[0:len(hWord)-1] + " "
    #returns the correct pronunciation of the whole word
    return pronWord

def pronounce(phrase):

    #splits the phrase so that you can get the correct pronunciation
    #of each word
    phrase1 = phrase.split()
    index = 0
    #creates empty string 'hPhrase'
    hPhrase = ""

    #loops through each word in the phrase
    while index < len(phrase1):

        #gets the pronunciation of each word in the phrase by running it
        #through the pronounceWord function
        hPhraseWord = pronounceWord(phrase1[index])
        #adds the correct pronunciation of each word to the
        #hPhrase string
        hPhrase = hPhrase + hPhraseWord
        index += 1

    #returns the pronunciation of the hawaiian phrase
    return hPhrase
        
def main():

    #gets the phrase and its pronunciation
    getHawaiianPhrase()
    #sees if the user wants to enter another phrase
    getChoice()

main()
