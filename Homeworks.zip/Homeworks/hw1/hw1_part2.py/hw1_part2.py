#File:     hw1_part2.py
#Author:   Gabe Maturo
#Date:     2/13/19
#Section:  5
#E-mail:   ak36939@umbc.edu
#Description:
#   Asks for user's income and cost of their favorite candy bar, and then prints out how many candy bars their daily income is worth

def main():
    income = float(input("What is your daily income? "))
    candy = float(input("How much does your favorite candy bar cost? "))
    print("You earned", income / candy, "candy bars today!")

main()
