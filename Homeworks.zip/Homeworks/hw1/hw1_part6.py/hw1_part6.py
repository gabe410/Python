#File:     hw1_part6.py
#Author:   Gabe Maturo
#Date:     2/13/19
#Section:  5
#E-mail:   ak36939@umbc.edu
#Description:
#   Asks user for information about a bill they've received and calcculates and prints how much they should pay in total

def main():
    bill = float(input("How much was the bill? "))
    percentTax = float(input("How much is tax in your area? "))
    percentTip = float(input("What percentage would you like to tip? "))
    print("The total cost of the meal will be", bill + (bill * (percentTax/100)) + (bill * (percentTip/100)))

main()
