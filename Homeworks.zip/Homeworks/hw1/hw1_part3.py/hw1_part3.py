#File:     hw1_part3.py
#Author:   Gabe Maturo
#Date:     2/13/19
#Section:  5
#E-mail:   ak36939@umbc.edu
#Description:
#   Asks users for their favorite musical instrument and prints out the instrument sounds lovely

def main():
    favoriteInstrument = input("What is your favorite instrument? ")
    print("The", favoriteInstrument, "sounds lovely!")

main()
