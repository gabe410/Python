#File:     hw1_part4.py
#Author:   Gabe Maturo
#Date:     2/13/19
#Section:  5
#E-mail:   ak36939@umbc.edu
#Description:
#   Asks user for information about a road trip they are planning and calculates and prints out the total cost of the trip

def main():
    gas = float(input("How much did the gas cost? "))
    snacks = float(input("How much did all of the snacks cost? "))
    tolls = float(input("What was the cost of the tolls? "))
    gloves = float(input("How much did the driving gloves cost? "))
    print("The total cost of the trip will be", gas + snacks + tolls + gloves)

main()
