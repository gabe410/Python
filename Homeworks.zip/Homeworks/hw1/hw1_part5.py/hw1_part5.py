#File:     hw1_part5.py
#Author:   Gabe Maturo
#Date:     2/13/19
#Section:  5
#E-mail:   ak36939@umbc.edu
#Description:
#   Asks the user for information about their name and prints a summary of the information

def main():
    familyName = input("What is your family name? ")
    firstName = input("What is your first name? ")
    title = input("What is your title? ")
    print("Please rise for", firstName, "of House", familyName + ",", title + "!")

main()
