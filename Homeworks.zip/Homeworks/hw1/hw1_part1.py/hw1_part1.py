#File:     hw1_part1.py
#Author:   Gabe Maturo
#Date:     2/13/19
#Section:  5
#E-mail:   ak36939@umbc.edu
#Description:
#   Prints out program about how many items you may have on your desk

def main():
    numMonitors = 2
    numMice = 4
    numEmptyBottles = 10
    print("I have", numMonitors, "monitors on my desk")
    print("I have", numMice, "mice on my desk")
    print("I have", numEmptyBottles, "empty bottles on my desk")
    print("I have a total of", numMonitors + numMice + numEmptyBottles, "items on my desk")

main()
