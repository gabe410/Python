#File:    hw3_part3.py
#Author:  Gabe Maturo
#Date:    2/24/19
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:    User is asked questions about being on a planet. Once they
#                enter valid values to all threee questions, the program
#                will display the information stored and entered by the user

def main():

    PLANT = "plant"

    ANIMAL = "animal"

    MINERAL = "mineral"
    
    species = input("Hello explorer! Please enter the type of object you are observing: ")

    #Says that if the user doesnt type plant, animal, or mineral to ask again

    while species != PLANT and species != ANIMAL and species != MINERAL:

        species = input("Invalid type. Must be 'plant', 'animal', or 'mineral': ")

    weight = float(input("Excellent. Please enter the weight in grams: "))

    #Says that the weight has to be greater than zero or else ask again

    while weight <= 0:

        weight = float(input("Invalid weight. Weight must be greater than zero: "))

    threatLevel = float(input("Thank you. Please enter the threat level of the object: "))

    while threatLevel < 0:

        threatLevel = float(input("INVALID INPUT! Threat too low! Threat level must be between 0 and 1, inclusively: "))

    #Says that threat level must be between zero and 1 or it asks again

    while threatLevel > 1:

        threatLevel = float(input("INVALID INPUT! Threat too high! Threat level must be between 0 and 1, inclusively: "))

    #Prints out all the stored information
    
    print("Data on", species, "weighing", weight, "grams with a threat level of", threatLevel, "has been recorded. Explore responsibly.")

main()
