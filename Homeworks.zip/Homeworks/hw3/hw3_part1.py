#File:    hw3_part1.py
#Author:  Gabe Maturo
#Date:    2/24/19
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:  This program simulates the up and down movement of a hailstone
#              in a storm

def main():

    hailstone = int(input("Please enter the height of the hailstone: "))

    #Means that hailstone must be positive
    
    while hailstone > 1:

        #Says that if the hailstone is even, divide it by two
        
        if hailstone % 2 == 0:

            hailstone = hailstone // 2

            print("Hailstone is currently at height", hailstone)

        #Says that if hailstone is odd, multiply it by 3 and add 1
        
        elif hailstone % 2 == 1:

            hailstone = (hailstone * 3) + 1

            print("Hailstone is currently at height", hailstone)

    print("Hailstone stopped at height", hailstone)

main()
