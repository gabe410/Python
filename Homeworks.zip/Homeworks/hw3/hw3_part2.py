#File:    hw3_part2.py
#Author:  Gabe Maturo
#Date:    2/24/19
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description: Calculates the answer to a multiplication problem

def main():

    firstNum = int(input("Please enter the first number: "))

    secondNum = int(input("Please enter the second number: "))

    multiplier = 0

    answer = 0

    #Says that any number times zero is zero
    
    if firstNum == 0 or secondNum == 0:

        answer = 0

    #Essentially "multiplies" the numbers
    
    while multiplier < firstNum:

        answer += secondNum

    #Adds secondNum to answer firstNum amount of times

        multiplier += 1

    #Prints out the whole function
    
    print(firstNum, "*", secondNum, "=", answer)

main()
