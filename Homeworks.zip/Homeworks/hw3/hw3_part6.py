#File:    hw3_part6.py
#Author:  Gabe Maturo
#Date:    2/24/19
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:    This program outputs a 'counting box' that has width
#                numbers on each line and height rows

def main():

    width = int(input("Please enter a width: "))

    height = int(input("Please enter a height: "))

    wCounter = 1

    #Prints the "counting box"
    
    while wCounter <= width * height:

        #Prints the width numbers and starts a new line height amount of times
        
        if wCounter%width != 0:

            print(wCounter, end=" ")

        elif wCounter%width == 0:

            print(wCounter)

        wCounter = wCounter + 1
            
main()
