#File:    hw3_part5.py
#Author:  Gabe Maturo
#Date:    2/24/19
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:   Prints numbers from 1-110 and prints special messages
#               for certain characteristics of the numbers

def main():

    count = 1

    #Counts to 110
    
    while count <= 110:

        #Prints the count for non-special numbers
        
        if count%3 != 0 and count%5 != 0:

            print(count)

        #Prints out the special message for a number divisible by 5 and 3
        
        if count%3 == 0:

            if count%5 == 0:

                print("Threeve. A combination of three and five. Simply stunning.")
            #Prints out special message for a number divisible by just 3
            
            else:

                print("Octopodes have three hearts.")

        #Prints out the special message for a number divisible by 5 and 3
        
        elif count%5 == 0:

            if count%3 == 0:

                print("Threeve. A combination of three and five. Simply stunning.")
            #Prints out the special message for a number divisible by 5
            
            else:

                print("Why where there only five golden rings?")

        count = count + 1
        
main()
