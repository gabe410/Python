#File:    hw3_part4.py
#Author:  Gabe Maturo
#Date:    2/24/19
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:     Program stores the number of pokemon caught and battle
#                 rating of each pokemon and then calculates and displays
#                 the average pokemon BR

def main():

    caught = int(input("How many pokemon did you catch today, young trainer? "))

    counter = 1

    pokemonSum = 0

    pokemon = 0

    #Makes sure user actually catches a number of pokemon

    while caught == 0:

        caught = int(input("Hohoho! Surely you caught more than that! How many was it really? "))

    #Asks what BR of each pokemon is and stores the values

    while counter <= caught:
        
        print("Pokemon #", counter)

        pokemon = int(input("What is the BR of this Pokemon? "))

        pokemonSum = pokemonSum + pokemon

        counter = counter + 1

    average = pokemonSum / caught    

    #Prints out all of the pokemon caught and the average BR

    print("Wicked! The", caught, "pokemon you caught had an average battle rating of:", average)

main()
