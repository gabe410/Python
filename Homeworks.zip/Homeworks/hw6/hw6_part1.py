#File:    hw6_part1.py
#Author:  Gabe Maturo
#Date:    4/22/2019
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:  Checks if a string is a palindrome and how many faults
#              it is allowed to be considered a palindrome

########################################################
# isFaultyPalindrome() determines if a string is a
# palindrome
# Input: word; a string that this function will assess
#        faultsPermitted; an integer representing the maximum
#                         tolerated faults in a word
# Output: True if word is a palindrome with at most
#         faultsPermitted faults, false otherwise
def isFaultyPalindrome(word, faultsPermitted):

    #Base case that says that if it runs out of the faults it is permitted
    #then stop the recursive case
    if faultsPermitted < 0:

        return False

    #Base case that says that if the word is one or less letters
    #than it is true
    if len(word) == 0 or len(word) == 1:

        return True

    else:

        #Recursive case that says that if the letters are the same,
        #than put it through the function again and don't subtract
        #the faults permitted
        if word[0] == word[len(word)-1]:

            return isFaultyPalindrome(word[1:len(word)-1], faultsPermitted)

        #Recursive case that says taht if the two letters are not the
        #same, put it through the function again but subtract one
        #from the faults permitted
        if word[0] != word[len(word)-1]:

            return isFaultyPalindrome(word[1:len(word)-1], faultsPermitted - 1)

     
def main():

    palWord = input("Input a word: ")
    faults = int(input("Input number of permitted faults: "))
    lastLetter = len(palWord) - 1

    #These if-else determine what to print out and "call" the function
    if isFaultyPalindrome(palWord, faults) == True:

        print("Looks good!")

    else:

        print("That's really not a palindrome.")

main()
