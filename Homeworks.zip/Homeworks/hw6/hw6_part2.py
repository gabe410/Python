#File:    hw6_part2.py
#Author:  Gabe Maturo
#Date:    4/22/2019
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:  Weaves two strings together one character at a time
#              and returns the resulting string

########################################################
# alternateCharacters(): Given two strings, return a string that
# alternates characters between the two strings
# Input: phrase1: the first string
# phrase2: the second string
# Output: a string that alternates characters between phrase1 and
# phrase2
def alternateCharacters(phrase1, phrase2):

    #Base cases that say that if one phrase is longer than the other,
    #stop the function and print out the rest of the longer phrase
    if 0 >= len(phrase1):

        return phrase2

    if 0 >= len(phrase2):

        return phrase1

    else:

        #recursive case that says to add the first letter of each word
        #and return the function without the letters that were just added
        #to the intertwined word
        phrase = phrase1[0] + phrase2[0]
        return phrase + alternateCharacters(phrase1[1:], phrase2[1:])
    
def main():

    firstPhrase = input("Say something: ")
    secondPhrase = input("Say something else: ")

    #prints the phrase
    print(alternateCharacters(firstPhrase, secondPhrase))

main()
