#File:    hw6_part3.py
#Author:  Gabe Maturo
#Date:    4/22/2019
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:  Implements modulo recursively

########################################################
# recursiveMod(): Given two positive integers, this function divides them and
#                 and gives the remainder
# Input: num1: the first integer
#        num2: the second integer
# Output: the remainder of when num1 and num2 are divided
def recursiveMod(num1, num2):

    #if the numbers equal each other then return 0
    if num1 == num2:

        return 0

    #if the second number is less than the first number, find the mod
    #by subtracting the second number from it recursively until
    #you have a remainder
    elif num2 < num1:

        return recursiveMod(num1-num2, num2)

    #otherwise just return the first number
    else:

        return num1

def main():

    number1 = int(input("Enter a number: "))
    number2 = int(input("Enter another number: "))

    #stores the value produced by the recursiveMod function to a variable
    mod = recursiveMod(number1, number2)

    #prints the entire equation
    print(str(number1)+ " % " + str(number2) + " = " + str(mod))
            

main()
    
