#File:    hw6_part4.py
#Author:  Gabe Maturo
#Date:    4/22/2019
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:  Draws a right triangle, using a height and symbols
#              provided by the user

########################################################
# recursiveTri(): Given a positive integer and two one-character strings,
#                 makes a right triangle with a fill
# Input: height: the height/length of the triangle
#        outline: the symbol that is to be the outline
#        fill: the symbol that is to be filled in the middle
#        maximum: total number of lines to make the triangle 
# Output: the traingle itself
def recursiveTri(height, outline, fill, maximum):

    #Base case saying that if it's only one letter or no letters
    #just print the outline
    if height == 0 or height == 1:

        print(outline)
        return
    #If the height is at the total number of lines, use recursion
    #to draw the rest of the triangle
    elif height == maximum:

        recursiveLine(height, outline, outline, height)
        recursiveTri(height-1, outline, fill, maximum)
        return

    #Otherwise use recursion to draw the triangle
    else:        

        recursiveLine(height, outline, fill, height)
        recursiveTri(height-1, outline, fill, maximum)

########################################################
# recursiveLine(): Draws the line for the triangle
# Input: length: the height/length of the triangle
#        outline: the symbol that is to be the outline
#        fill: the symbol that is to be filled in the middle
#        maximum: total number of lines to make the triangle
# Output: the lines for the triangle
def recursiveLine(length, outline, fill, maximum):

    #Base case saying that if the length is only one, just print
    #the outline character
    if length == 1:

        print(outline, end="")
        return

    #Recursive case that prints each line and determines what symbol
    #to print to make each line
    else:

        recursiveLine(length-1, outline, fill, maximum)

        if length == maximum:
            print(outline)

        else:
            print(fill,end="")



def main():

    triHeight = int(input("Please enter the height of the triangle: "))
    triOutline = input("Please enter the outline symbol to use: ")
    triFill = input("Please enter the fill symbol to use: ")

    #Calling the function to print the triangle with the height
    #and symbols the user provided
    recursiveTri(triHeight, triOutline, triFill, triHeight)

main()
