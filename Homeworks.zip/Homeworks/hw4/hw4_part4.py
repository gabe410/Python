#File:    hw4_part4.py
#Author:  Gabe Maturo
#Date:    3/3/2019
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:  This program lets the user make a grocery list that gives them
#              a breakdown of each item they want to buy and the amount that
#              should be purchased

def main():

    STOP = "END"

    item = input("Please enter an item, or 'END' to stop: ")

    itemList = []

    purchaseList = []

    index = 0

    sumIndex = 0

    total = 0
    
    while item != STOP:

        itemList.append(item)
        
        buy  = int(input("Please enter the amount to buy: "))

        purchaseList.append(buy)

        item = input("Please enter an item, or 'END' to stop: ")

    print("Here is your grocery list: ")
    
    while index < len(itemList):

        print("Purchase", purchaseList[index], "of", itemList[index])

        index += 1

    while sumIndex < len(purchaseList):

        total = total + purchaseList[sumIndex]

        sumIndex += 1

    print("Total of", total, "to be purchased")

       
main()
