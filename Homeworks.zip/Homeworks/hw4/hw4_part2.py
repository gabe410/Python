#File:    hw4_part2.py
#Author:  Gabe Maturo
#Date:    3/3/2019
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:  Creates a program where user creates a list of the superpowers
#              that they have and then prints out the total number of
#              superpowers as well as if they are underpowered, perfect
#              or too strong

def main():

    #Sentinel value to stop asking for superpowers
    
    STOP = "QUIT"

    superpower = input("Please enter a superpower ('QUIT' to stop) : ")

    #List to store the superpowers
    
    superpowerTotal = []

    #Says to keep asking for superpowers until the user types "QUIT"
    
    while superpower != STOP:

        superpower = input("Please enter a superpower ('QUIT' to stop) : ")

        #Adds the superpowers that the user enters into the list
        
        superpowerTotal.append(superpower)

    #The next 3 if statements determine and print if the superhero is perfect 
    #or not based on the length of the list
    
    if len(superpowerTotal) > 3:

        print("You have", len(superpowerTotal), "superpowers\nYou're too strong!")

    if len(superpowerTotal) < 3:

        print("You have", len(superpowerTotal), "superpowers\nYou are underpowered!")

    if len(superpowerTotal) == 3:

        print("You have", len(superpowerTotal), "superpowers\nYou're a perfect superhero!")

main()


           
