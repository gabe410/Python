#File:    hw4_part3.py
#Author:  Gabe Maturo
#Date:    3/3/2019
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:  This program asks the user to enter a password and then
#              checks it for different requirements before approving it as
#              secure and repeating the final password back to the user

def main():
    
    passwordValid = False

    #Setting up the use of boolean flag to check requirements for the password
    
    while not passwordValid:

        password = input("Please enter a password: ")

        passwordValid = True

        #Checks to make sure password is 6 characters long

        if len(password) < 6:

            print("Password must be at least 6 characters")

            passwordValid = False

        #Checks to make sure password is less than 20 characters long
            
        if len(password) > 20:

            print("Password must be no longer than 20 characters")

            passwordValid = False

        #Checks that if the password is between 6 and 13 characters, it has to have a 7 somewhere in it

        if len(password) >= 6 and len(password) <= 13 and "7" not in password:

            print("Shorter passwords must contain a 7")

            passwordValid = False

        #Checks that if the password is between 14 and 20 characters, it has to have a 2 somewhere in it
            
        if len(password) >= 14 and len(password) <= 20 and "2" not in password:

            print("Longer passwords must contain a 2")

            passwordValid = False

        #Checks to make sure 0 and O are not in the same password

        if "O" in password and "0" in password:

            print("Password cannot contain a O and a 0 at the same time")

            passwordValid = False

        #Checks to make sure password has an uppercase letter

        if password == password.lower():

            print("Password must have an uppercase letter")

            passwordValid = False

        #Checks to make sure password has a lowercase letter

        if password == password.upper():

            print("Password must have a lowercase letter")

            passwordValid = False

    print("Thank you for picking the secure password", password)

main()
