#File:    hw4_part4.py
#Author:  Gabe Maturo
#Date:    3/2/2019
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:  Draws an isosceles right triangle with an outline and a fill

def main():

    height = int(input("Please enter the height of the triangle: "))

    outline = input("Please enter a symbol for the triangle outline: ")

    fill = input("Please enter a symbol for the triangle fill: ")

    counter = 0

    outlineVal = []

    index = 0

    #Creates a list that stores a row with all x's
    
    while counter < height:

        outlineVal.append(outline)

        counter += 1

    #Prints the first row of all outline symbols

    print(outlineVal)

    #Replaces the all outline symbols with the fill symbol in between
    #the two outline symbols
        
    while index < len(outlineVal) - 1:

        if index == 0 or index == len(outlineVal) - 1:

            print(end="")

        else:

            outlineVal[index] = fill

        index += 1

    #Prints each row as it goes down, removing one fill each time
    #Until there is just one outline left in the last row
    
    while len(outlineVal) > 1:

        fillVal = outlineVal[1]
        
        outlineVal.remove(fillVal)

        print(outlineVal)
        
main()
