#File:    hw4_part5.py
#Author:  Gabe Maturo
#Date:    3/3/2019
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:  This program outputs a specific respomse based on whether
#              a word starts with "pre" or "post"

def main():

    MAX_WORDS = 10

    wordList = []

    listLength = 0
    
    index = 0

    #Asks the user to enter in 10 words
    
    while listLength < MAX_WORDS:

        word = input("Please enter a word: ")

        #Says that if the word starts with "pre" to store a special message
        #to the word list
        
        if word[0:3] == "pre":

            wordList.append("You should " + word[3:len(word)] + " early")

        #Says that if the word starts with post to store a special message
        #to the word list
            
        elif word[0:4] == "post":

            wordList.append("You should " + word[4:len(word)] + " later")

        #Says that any other word is to be stored in the word list with a
        #different special message
            
        else:

            wordList.append("You can " + word + " whenever!")

        listLength += 1

    #Prints out the list with all ten words and their special messages

    while index < len(wordList):

        print(wordList[index])

        index += 1
        
main()
            
    
