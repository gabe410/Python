#File:   hw0.py
#Author: Gabe Maturo
#Date:   January 30 2019
#Section: 01
#E-mail: ak36939@umbc.edu
#Description:  This file is to help students practice using the submission system on the GL servers for CMSC 201.

print("This is going to be a great semester!")
