#File:    hw2_part4.py
#Author:  Gabe Maturo
#Date:    2/20/19
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:
    #This program plays a simple game where the user is asked about their dog
    #and attempts to guess the dog's breed based on their answers

def main():

    print("Please enter 'yes' or 'no' to these questions.")
    coat = input("Does your dog have a fluffy coat? ")

    if(coat == "yes"):
        breed = input("Is your dog an American breed? ")
        if(breed == "yes"):
            print("Your dog is a Chesapeake Bay Retriever!")
        elif(breed == "no"):
            print("Your dog is a Visla!")
    elif(coat == "no"):
        size = input("Is your dog a small dog? ")
        if(size == "yes"):
            print("Your dog is a Japanese Spitz!")
        elif(size == "no"):
            haircut = input("Does your dog need a haircut to do its job? ")
            if(haircut == "yes"):
                print("Your dog is a Standard Poodle!")
            if(haircut == "no"):
                print("Your dog is a Kuvasz!")

main()
