#File:    hw2_part3.py
#Author:  Gabe Maturo
#Date:    2/20/19
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:
    #The uer enters two integers to use and the operation they would like to do
    #When done, the progra prints out the equation along with the answer

def main():

    firstInt = int(input("Please enter the first integer: "))
    secondInt = int(input("Please enter the second integer: "))
    print("The options are minus and mod.")
    operation = input("What operation do you want to perform? ")

    if(operation == "minus" and secondInt >= firstInt):
        print(secondInt, "-", firstInt, "=", secondInt-firstInt)
    elif(operation == "minus" and firstInt >= secondInt):
        print(firstInt, "-", secondInt, "=", firstInt-secondInt)
    elif(operation == "mod" and secondInt >= firstInt):
        print(secondInt, "%", firstInt, "=", secondInt%firstInt)
    elif(operation == "mod" and firstInt >= secondInt):
        print(firstInt, "%", secondInt, "=", firstInt%secondInt)
    else:
        print("Invalid operation.")
main()
