#File:     hw2_part2.py
#Author:   Gabe Maturo
#Date:     2/20/19
#Section:  5
#E-mail:   ak36939@umbc.edu
#Description:
    #Asks user for a number and whether they would like to round the number
    #up or down, then the program will calculate the rounded number and
    #print the result

def main():
    roundNumber = float(input("Input the number you are rounding: "))
    roundDecision = input("Do you want to round up or down? ")

    if(roundNumber % 1 == 0):
        print("Original number:", roundNumber)
        print("No rounding needed...")
        print("Rounded number:", roundNumber)
    elif(roundDecision == "up"):
        print("Original number:", roundNumber)
        print("Rounding up...")
        print("Rounded number:", (roundNumber // 1) + 1)
    elif(roundDecision == "down"):
        print("Original number:", roundNumber)
        print("Rounding down...")
        print("Rounded number:",roundNumber // 1)
    else:
        print("Original number:", roundNumber)
        print("Invalid choice...")

main()
