#File:    hw2_part1.py
#Author:  Gabe Maturo
#Date:    2/20/19
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:
    #Gives feedback after asking the user what they're majoring in
    #allowing for the user to select up to two areas of study

def main():

    print("Input your major(s). Use 'NONE' if you don't have a response")
    major1 = input("What is your first major? ")
    major2 = input("What is your second major? ")

    if(major1 == "NONE" and major2 == "NONE"):
        print("You need to pick a major soon!")
    elif(major1 == major2):
        print("You can't double major in the same thing!")
    elif(major1 == "NONE"):
        print("It's cool that you're focusing on", major2)
    elif(major2 == "NONE"):
        print("It's cool that you're focusing on", major1)
    elif(major1 == "CMSC" and major2 == "CMPE"):
        print("You can't major in CMSC and CMPE, unfortunately")
    elif(major1 == "CMPE" and major2 == "CMSC"):
        print("You can't major in CMSC and CMPE, unfortunately")
    else:
        print(major1, "and", major2, "sounds like a cool combination!")

main()
