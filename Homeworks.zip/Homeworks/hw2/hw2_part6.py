#File:    hw2_part6.py
#Author:  Gabe Maturo
#Date:    2/20/19
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:
    #Asks user about the state of two generators and then uses their input
    #to determine the state of the generator

def main():

    print("Please enter 'y' for yes and 'n' for no")
    firstSwitch = input("Is the first switch on? (y/n) ")
    secondSwitch = input("Is the second switch on? (y/n) ")

    if(firstSwitch == secondSwitch):
        print("The generator is off.")
    else:
        print("The generator is on.")

main()
