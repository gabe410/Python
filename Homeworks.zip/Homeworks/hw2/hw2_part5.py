#File:    hw2_part5.py
#Author:  Gabe Maturo
#Date:    2/20/19
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:
    #Asks user to enter day of the month and responds with correct day of the
    #week

def main():

    day = int(input("Please enter the day of the month: "))

    if(day > 28):
        print("The date", day, "is an invalid day.")
    elif(day % 7 == 7):
        print("Today is Thursday!")
    elif(day % 7 == 6):
        print("Today is Wednesday!")
    elif(day % 7 == 5):
        print("Today is Tuesday!")
    elif(day % 7 == 4):
        print("Today is Monday!")
    elif(day % 7 == 3):
        print("Today is Sunday!")
    elif(day % 7 == 2):
        print("Today is Saturday!")
    elif(day % 7 == 1):
        print("Today is Friday!")

main()
