#File:    hw5_part4.py
#Author:  Gabe Maturo
#Date:    3/9/2019
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:  This program translates English into Pig Latin

#translate() takes a single english word and translates it to pig latin
#Parameters: english_word; an English word
#Return: the pig latin translation
def translate():

    phrase = input("Enter an English phrase: ")

    translator = phrase.split()

    index = 0

    index3 = 0

    #this is the while loop that essentially 'translates' the English
    #word to pig latin
    while index < len(translator):

        firstLetter = translator[index][0]

        #says that if it is a vowel or the first word, you don't switch the letters up
        if firstLetter.lower() == "a" or firstLetter.lower() == "e" or firstLetter.lower() == "i" or firstLetter.lower() == "o" or firstLetter.lower() == "u" or index == 0:

            translator[index] = translator[index] + str("ay")
            
        else:    
            
            #stores everything but the first letter of the word
            translator[index] = translator[index][1:len(translator[index])]

            #adds the first letter of the word to the end and then adds 'ay'
            translator[index] = translator[index] + firstLetter + str("ay")

        index += 1
        
    #prints out the translated form for the first word since it has a special
    #rule and then prints out the other words
    print("I think you meant to say: ", end="")
    
    while index3 < len(translator):
    
        print(translator[index3], end=" ")    

        index3 += 1

    print()
          
def main():
    
    #calls the function
    translate()

main()
