#File:    hw5_part5.py
#Author:  Gabe Maturo
#Date:    3/9/2019
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:  Asks for the number of words the user will enter into the
#              program and then prompts for each of the words and stores them.
#              Once all the words have been entered, the porgram prints them
#              out in reverse order from how they were entered, and shows
#              what the words would be backwards.

#backwards() reverses a string and returns the result
#Parameters: forString; a string to reverse
#Return: backString; the reversed string
def backwards():

    count = 0
    
    index = 0

    backwardsList = []

    wordList = []
    
    words = int(input("How many words would you like to turn backwards: "))

    #allows the user to enter how every many words they chose in the first
    #question and then reverses each string through nested while loops
    while count < words:

        string = input("Please enter string # " + str(count + 1) + ": ")

        #adds normal wors to the 'normal' list
        wordList.append(string)
        
        count += 1

        reverse = string
        
        index2 = len(reverse)

        letter = len(reverse) - 1 

        word = 0

        reversedWord = " "

        #reverses the words
        while index2 > 0:

            reversedWord += reverse[letter]
            
            index2 -= 1

            letter -= 1

        #adds the words to the backwards words list
        backwardsList.append(reversedWord)
            
    index3 = len(wordList) - 1 

    #prints out the list of normal and backwards words from the last words
    #entered by the user to the first
    while index3 >= 0:

        print("The string '"+str(wordList[index3])+"' reversed is '"+str(backwardsList[index3])+"'.") 

        index3 -= 1
        
def main():
    
    #calls the function
    backwards()

main()
