#File:    hw5_part3.py
#Author:  Gabe Maturo
#Date:    3/9/2019
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:  This program gets the user to enter a phrase and then a word.
#              After the input is gathered, the program will search for
#              the word entered in the phrase to see how many times it
#              occurs in the phrase

#def inPhrase() takes in the phrase and the word and tells you how many times
#and where the word is found in the phrase
#Parameters: phrase and a word
#Return: none
def inPhrase():

    phrase = input("Please enter a phrase: ")

    #makes the phrase case insensitive
    phrase = phrase.lower()
    
    word = input("Please enter a word to search for: ")

    #makes the word to search for case insensitive
    word = word.lower()
    
    index = 0

    counter = 0

    #makes sure the word to search for is not longer than the phrase
    while len(word) > len(phrase):

        print("The word cannot be longer than the phrase.")

        #asks the user again but this time for a word shorter than the phrase
        word = input("Please enter a shorter word to search for: ")

    #checks to see where in the phrase the word to search for is located and prints
    #if it is found
    while index <= len(phrase)-len(word):

        if phrase[index : index + len(word)] == word:

            counter += 1
            
            print("Found " + word + " at index " + str(index))

        index += 1
        
    #prints total number of times that the word is found
    print("Found " + word + " a total of " + str(counter) + " times")
    
def main():

    #calls the function
    inPhrase()

main()
    
