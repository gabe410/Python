#File:    hw5_part1.py
#Author:  Gabe Maturo
#Date:    3/9/2019
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description:  Asks user for their name and prints their initials

#getInitials() counts the instances of a letter in a string
#Parameters: name; a string containing the name of the user
#Return: none
def getInitials():

    index = 0
    
    initials = input("Enter your name: ")

    #splits the whitespace of the words entered
    firstLetter = initials.split()

    #prints the first letter/index of each word which is what initials are
    while index < len(firstLetter):

        print(firstLetter[index][0].upper() + ".", end="")

        index += 1
        
def main():

    #calling the function inside of main
    getInitials()

main()
    
