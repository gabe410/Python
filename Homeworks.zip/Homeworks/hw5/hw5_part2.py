#File:    hw5_part2.py
#Author:  Gabe Maturo
#Date:    3/9/2019
#Section: 5
#E-mail:  ak36939@umbc.edu
#Description: Counts how many words in a sentence look like they
#             are in past tense

#countPastTense() counts past tense words
#Parameters: phrase; a string to count past tense words
#Return: none
def countPastTense():
    
    word = input("Tell me something: ")

    #splits the words in the phrase up for easier access
    wordSplit = word.split()

    index = 0

    counter = 0

    #finds and prints if there is an ed in the phrase and how many times
    while index < len(wordSplit):

        #finds the ed in the phrase
        if "ed" in wordSplit[index]:

            #counts each time ed is in the phrase
            counter += 1

        index += 1

    #prints out how many times ed was found
    print ("There appear to be " + str(counter) + " past tense words in that.")
    
def main():

    #calls the function used
    countPastTense()

main()
