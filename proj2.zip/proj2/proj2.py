# File:    proj2.py
# Date:    4/8/19
# Section: 5
# E-mail:  ak36939@umbc.edu
# Description:
#    Plays the game of Reversi

#info for game pieces and board
X = "X"
O = "O"
LINE = "|"
UNDERLINE = "_"

#the game board, an empty 2D list
gameBoard = [[],[],[],[],[],[],[],[]]

###################################################
# getMove() prompts and reprompts the user with valid
#           moves and asks for a move until they select a valid move
# Parameters: none;
# Return:     move; a coordinate composed of
#                         2 integers, chosen by the user
def getMove():

    #shows the user the valid moves before asking for their move
    possibleMoves = validMoves(gameBoard,X)
    print("Valid moves are: " + str(possibleMoves))

    move = input("Enter a move: ")
    #separates the move into 2 parts
    move = move.split()

    if len(move) == 2:

        move = [int(move[0]),int(move[1])]

    #make sure the player makes a valid move
    while move not in possibleMoves:

        print("Invalid move. Valid moves are: " + str(possibleMoves))
        move = input("Enter a move: ")
        move = move.split()

        #see if the move is valid
        if len(move) == 2:

            move = [int(move[0]),int(move[1])]

    return move

###################################################
# makeMove() takes user move and applies it to the gameboard
#            and executes CPU move
# Parameters: move; the coordinates the user has chosen
# Return:     none; function puts move on the board
def makeMove(move):
    
    #set the piece on the gameboard and flip the moves if necessary
    gameBoard[move[0]][move[1]] = X
    moves = flip(gameBoard,move)
    gameboard(gameBoard,moves,X)

###################################################
# cpuMove() makes the CPU move to be the first available
#           valid move
# Parameters: availablemoves; the valid moves available
# Return:     computerMove; the computer's move in the game
def cpuMove(availablemoves):

    #chooses the first available move
    computerMove = availablemoves[0]
    return computerMove


###################################################
# validMoves() finds what the valid moves in the game are
# Parameters: board; the 2D list containing the updated game board
#             piece; the letter of the person getting moves
# Return:     moves; the valid moves that can be executed
def validMoves(board,piece):

    #create a new list of valid moves
    moves = []

    #go over each row and column on the gameboard
    for row in range(len(board)):

        for column in range(len(board[row])):

            #see if the move is an empty one
            if board[row][column] == UNDERLINE:

                #Get the opposite piece
                if piece == X:
                    oppositePiece = O

                elif piece == O:
                    oppositePiece = X

                #make sure the move is a good/valid one
                goodMove = False

                #iterate over the left side
                x = row - 1
                y = column
                while x >= 0 and board[x][y] == oppositePiece:

                    x = x - 1

                if x >= 0 and x < row - 1 and board[x][y] == piece:

                    goodMove = True

                #iterate over the right side
                x = row + 1
                y = column

                while x < 8 and board[x][y] == oppositePiece:

                    x = x + 1

                if x < 8 and x > row + 1 and board[x][y] == piece:

                    goodMove = True

                #iterate over the top side
                x = row
                y = column - 1

                while y >= 0 and board[x][y] == oppositePiece:

                    y = y - 1

                if y >= 0 and y < column - 1 and board[x][y] == piece:

                    goodMove = True

                #iterate over the bottom side
                x = row
                y = column + 1

                while y < 8 and board[x][y] == oppositePiece:

                    y = y + 1

                if y < 8 and y > column + 1 and board[x][y] == piece:

                    goodMove = True

                #add the move to the list of moves if it is valid
                if goodMove == True:

                    moves.append([row,column])

    return moves

###################################################
# gameboard() updates the gameboard after each move
# Parameters: board; the gameboard (2D List)
#             moves; the moves to be executed
#             symbol; the piece to be put on the board
# Return:     board; the updated game board (2D list)
def gameboard(board,moves,symbol):

    #make each move in the list of moves
    for i in range(len(moves)):

        move = moves[i]
        #get and set
        board[move[0]][move[1]] = symbol

    return board

######################################################################
# printBoard() prints the Reversi board with the right headings
# Parameters:  board; a 2D list of single-character strings (X, O, _)
# Output:      None
def printBoard(board):
    print("Current board:")

    print("_|0|1|2|3|4|5|6|7")

    #print each row of the board
    for i in range(len(board)):

        print(str(i) + LINE + LINE.join(board[i]) + LINE)

###################################################
# winner() determines if someone has won the game
#          and how many points each player has
# Parameters: None;
# Return:   player, computer or tie; depends on who wins
#                                    the game but returns the winner
def winner():

    computerScore = 0
    playerScore = 0

    #for each cell in the board
    for x in range(8):

        for y in range(8):

            #count each piece
            if gameBoard[x][y] == X:
                playerScore = playerScore + 1

            elif gameBoard[x][y] == O:
                computerScore = computerScore + 1

    print("Player score: " + str(playerScore))
    print("CPU score: " + str(computerScore))

    #return whichever is the winner
    if playerScore > computerScore:
        return "player"

    elif computerScore > playerScore:
        return "computer"

    elif computerScore == playerScore:
        return "tie"

###################################################
# flip() determines if a piece needs to be flipped
#        and in what direction to flip it, and executes the flip
# Parameters: board; the whole current gameboard (2D list)
#             move; the move being made
# Return:   moves; the 2D list with all the flips applied
def flip(board,move):

    piece = board[move[0]][move[1]]

    #Get the opposite piece
    if piece == X:
        oppositePiece = O

    elif piece == O:
        oppositePiece = X

    moves = []

    #go over each move and see if it needs flipping

    #the left side
    x = move[0] - 1
    y = move[1]
    tempMoves = []

    while x >= 0 and board[x][y] == oppositePiece:

        tempMoves.append([x,y])
        x = x - 1

    if x >= 0 and x < move[0] - 1 and board[x][y] == piece:

        for i in range(len(tempMoves)):

            moves.append(tempMoves[i])

    #the right side
    x = move[0] + 1
    y = move[1]
    tempMoves = []

    while x < 8 and board[x][y] == oppositePiece:

        tempMoves.append([x,y])
        x = x + 1

    if x < 8 and x > move[0] + 1 and board[x][y] == piece:


        for i in range(len(tempMoves)):

            moves.append(tempMoves[i])

    #the top
    x = move[0]
    y = move[1] - 1
    tempMoves = []

    while y >= 0 and board[x][y] == oppositePiece:

        tempMoves.append([x,y])
        y = y - 1

    if y >= 0 and y < move[1] - 1 and board[x][y] == piece:

        for i in range(len(tempMoves)):

            moves.append(tempMoves[i])

    #the left
    x = move[0]
    y = move[1] + 1
    tempMoves = []

    while y < 8 and board[x][y] == oppositePiece:

        tempMoves.append([x,y])
        y = y + 1

    if y < 8 and y > move[1] + 1 and board[x][y] == piece:

        for i in range(len(tempMoves)):

            moves.append(tempMoves[i])

    return moves

def main():

    gameWon = False

    #fill the game board with 8 columns
    for i in range(8):

        gameBoard[i] = [UNDERLINE,UNDERLINE,UNDERLINE,UNDERLINE,UNDERLINE,UNDERLINE,UNDERLINE,UNDERLINE]

    #set the pieces in the center of the board
    gameBoard[3][3] = X
    gameBoard[3][4] = O
    gameBoard[4][3] = O
    gameBoard[4][4] = X


    #start the game loop
    while gameWon == False:

        printBoard(gameBoard)

        #get the user's move
        move = getMove()

        #make the move and flip the board
        makeMove(move)

        #see if there are any possible moves
        possibleMoves = validMoves(gameBoard,O)

        if len(possibleMoves) == 0:
            gameWon = True

        else:
            #makes the computer move
            computermove = cpuMove(validMoves(gameBoard,O))

            #flips the board and tells the player what move they made
            gameBoard[computermove[0]][computermove[1]] = O
            moves = flip(gameBoard,computermove)
            gameboard(gameBoard,moves,O)
            print("CPU takes move: " + str(computermove))

        #checks if there are any moves
        possibleMoves = validMoves(gameBoard,X)

        if len(possibleMoves) == 0:
            gameWon = True

    #shows the board one last time
    print("Game Over")
    printBoard(gameBoard)

    #says how many pieces each person has
    theWinner = winner()

    #says who won
    if theWinner == "player":
        print("Player wins!")

    elif theWinner == "computer":
        print("The computer has won!")

    elif theWinner == "tie":
        print("You tied!")

main()
